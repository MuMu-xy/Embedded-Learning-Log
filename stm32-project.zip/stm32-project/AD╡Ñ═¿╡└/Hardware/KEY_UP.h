#ifndef __KEY_UP_H_
#define __KEY_UP_H_

uint8_t Key_UP(void);
void Key_UP_Init(void);


#endif
