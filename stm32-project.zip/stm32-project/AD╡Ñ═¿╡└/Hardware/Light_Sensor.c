#include "stm32f10x.h"                  // Device header

void Light_Sensor_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOF,ENABLE);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU ;/*��������*/	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	
	GPIO_Init(GPIOF,&GPIO_InitStructure);
}

uint8_t Light_Sensor_Get(void)
{
	return GPIO_ReadOutputDataBit(GPIOF,GPIO_Pin_8);
	
}

