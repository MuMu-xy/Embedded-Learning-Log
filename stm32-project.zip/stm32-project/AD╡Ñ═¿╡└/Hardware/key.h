#ifndef __key_H_
#define __key_H_

void Key_Init(void);
uint8_t Key_GetNum(void);

#endif
