#ifndef __LIGHT_SENSOR_H_
#define __LIGHT_SENSOR_H_

void Light_Sensor_Init(void);
uint8_t Light_Sensor_Get(void);

#endif
