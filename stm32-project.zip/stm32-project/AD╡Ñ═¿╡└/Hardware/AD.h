#ifndef __AD_H_
#define __AD_H_

void AD_Init(void);
uint16_t AD_IGetValue(void);


#endif

