#include "stm32f10x.h"                  // Device header

uint16_t CountSensor_count;

void CountSensor_Init(void)
{
	GPIO_InitTypeDef GPIO_InitSture;
	EXTI_InitTypeDef EXTI_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructuer;
	GPIO_InitSture.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitSture.GPIO_Pin = GPIO_Pin_14;
	GPIO_InitSture.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIO_InitSture);/*��ʼ��GPIO*/

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);
	
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOB,GPIO_PinSource14);/*��ʼ��AFIO�ж�����ѡ��*/
	
	EXTI_InitStructure.EXTI_Line = EXTI_Line14;
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising_Falling;/*�½���*/
	EXTI_Init(&EXTI_InitStructure);/*��ʼ�����ؼ�⼰����*/
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);/*2λ��ռ2λ��Ӧ*/
	
	NVIC_InitStructuer.NVIC_IRQChannel = EXTI15_10_IRQn;
	NVIC_InitStructuer.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructuer.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructuer.NVIC_IRQChannelSubPriority = 1;
	NVIC_Init(&NVIC_InitStructuer);	/*���ȼ���Ϊ1*/
}

uint16_t CountSensor_Get(void)
{
	return CountSensor_count;
}


void EXTI15_10_IRQHandler(void)
{
	if(EXTI_GetITStatus(EXTI_Line14) == SET)
	{
		CountSensor_count++;
		EXTI_ClearITPendingBit(EXTI_Line14);
	}
}



