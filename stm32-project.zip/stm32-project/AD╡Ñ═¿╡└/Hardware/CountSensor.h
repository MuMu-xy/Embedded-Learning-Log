#ifndef __COUNTSENSOR_H_
#define __COUNTSENSOR_H_

void CountSensor_Init(void);
uint16_t CountSensor_Get(void);


#endif
