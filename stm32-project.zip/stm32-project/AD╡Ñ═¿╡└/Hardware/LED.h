#ifndef __LED_H
#define __LED_H

void LED_Init(void);
void LED1_ON(void);
void LED2_ON(void);
void LED1_OFF(void);
void LED2_OFF(void);
void Buzzer_ON(void);
void Buzzer_OFF(void);
void LED1_turn(void);
void LED2_turn(void);
void Buzzer_turn(void);


#endif
