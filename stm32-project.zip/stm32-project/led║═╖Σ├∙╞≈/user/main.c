#include "stm32f10x.h"                  // Device header
#include "Delay.h"

int main(void)
{
		GPIO_InitTypeDef GPIO_InitStructuer;
RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);/*��ʼ��ʱ��*/
		GPIO_InitStructuer.GPIO_Mode = GPIO_Mode_Out_PP;/*����Ϊ�������*/
		GPIO_InitStructuer.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_5;/*��������*/
		GPIO_InitStructuer.GPIO_Speed = GPIO_Speed_50MHz;/*��ʼ���ٶ�*/
	GPIO_Init(GPIOB,&GPIO_InitStructuer);
	while(1)
	{
		GPIO_SetBits(GPIOB,GPIO_Pin_8);
		GPIO_ResetBits(GPIOB,GPIO_Pin_5);
		Delay_ms(500);
		GPIO_ResetBits(GPIOB,GPIO_Pin_8);
		GPIO_SetBits(GPIOB,GPIO_Pin_5);
		Delay_ms(500);

	}
	
}
