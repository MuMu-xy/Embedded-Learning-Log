#ifndef __TIMER_H_
#define __TIMER_H_

void Timer_Init(void);
uint16_t Timer_Counter(void);

#endif
