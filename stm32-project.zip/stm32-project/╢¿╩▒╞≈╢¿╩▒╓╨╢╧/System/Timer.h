#ifndef __TIMER_H_
#define __TIMER_H_

void Timer_Init(void);

#endif
