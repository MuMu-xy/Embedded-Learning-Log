#ifndef __PWM_H_
#define __PWM_H_


void PWM_Init(void);
void PWM_SetCompare1(uint16_t compare);
	
#endif
