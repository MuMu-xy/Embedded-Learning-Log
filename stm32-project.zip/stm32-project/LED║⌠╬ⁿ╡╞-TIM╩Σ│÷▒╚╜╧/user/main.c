#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "LED.h"
//#include "key.h"
//#include "KEY_UP.h"
//#include "Light_Sensor.h"
#include "OLED.h"
//#include "CountSensor.h"
#include "PWM.h"

uint8_t i;

int main(void)
{
	LED_Init();
	OLED_Init();
	PWM_Init();
	
	while(1)
	{	
		for(i = 0;i <= 100;i++)
		{
			PWM_SetCompare1(i);
			Delay_ms(10);
		}
		for(i = 0;i <= 100;i++)
		{
			PWM_SetCompare1(100-i);
			Delay_ms(10);
		}
	}
	
}
