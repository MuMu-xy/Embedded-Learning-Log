#ifndef __AD_H_
#define __AD_H_

void AD_Init(void);
uint16_t AD_GetValue(uint8_t ADC_Channel);


#endif

