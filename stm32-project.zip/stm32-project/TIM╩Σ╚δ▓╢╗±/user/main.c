#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "LED.h"
//#include "key.h"
//#include "KEY_UP.h"
//#include "Light_Sensor.h"
#include "OLED.h"
//#include "CountSensor.h"
#include "PWM.h"
#include "IC.h"

uint8_t i;

int main(void)
{
	LED_Init();
	OLED_Init();
	PWM_Init();
	IC_Init();
	
	OLED_ShowString(1,1,"Freq:00000Hz");
	OLED_ShowString(2,1,"Duty:00%");
	PWM_SetPrescaler(7200-1); 	/* FREQ = 72M / (PSC + 1)/100 */
	PWM_SetCompare1(30);		/*Duty = CCR / 100*/
	
	while(1)
	{	
	OLED_ShowNum(1,6,IC_GetFreq(),5);
	OLED_ShowNum(2,6,IC_GetDuty(),2);
	}
	
}
