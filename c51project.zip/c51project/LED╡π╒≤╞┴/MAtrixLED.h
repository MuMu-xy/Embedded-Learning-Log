#ifndef __MAtrixLED_H__
#define __MAtrixLED_H__
void Matrix_Init();
void _74HC595_(unsigned char num);
void Matrix(unsigned char column,num);
#endif