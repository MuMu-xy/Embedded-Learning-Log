#ifndef __buzzer_H__
#define __buzzer_H__

void buzzeer_time (unsigned int ms);

#endif