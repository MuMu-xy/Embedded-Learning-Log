#include <REGX52.H>

sbit DS1302 = 
